version: 5.0.2

1. update packages
2. fix some design issues
